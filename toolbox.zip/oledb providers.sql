 --OLE DB Providers registered to this server
 EXEC master.dbo.sp_MSset_oledb_prop 

 --DB2OLEDB = Microsoft-provided as400 OLE DB driver for AS400 as found in SQL Server version-specific feature pack 
 --Microsoft.ACE.OLEDB.12.0 = MS Access

 --Default list

--SQLOLEDB
--SQLNCLI11
--Microsoft.ACE.OLEDB.12.0
--ADsDSOObject
--SSISOLEDB
--Search.CollatorDSO
--MSDASQL
--MSOLAP
--MSDAOSP