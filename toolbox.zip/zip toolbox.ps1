cd E:\OneDrive\toolbox
Compress-Archive -Path * -DestinationPath toolbox.zip -Force
