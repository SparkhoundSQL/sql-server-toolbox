--Use to backup database master keys used for row-level encryption. 
--Not so useful for TDE, instead see: toolbox\lab - tde encryption workshop 2014.sql

sp_msforeachdb 'use [?];
if exists(select * from sys.symmetric_keys where name = ''##MS_DatabaseMasterKey##'')
select ''
USE [?];   
GO  
OPEN MASTER KEY DECRYPTION BY PASSWORD = '''''''';   

BACKUP MASTER KEY TO FILE = ''''c:\temp\?_dbmaster_20200131.key''''
    ENCRYPTION BY PASSWORD = '''''''';
GO  ''';