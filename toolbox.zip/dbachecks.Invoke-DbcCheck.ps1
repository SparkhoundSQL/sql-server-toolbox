#DBAChecks template
#Doc: https://dbatools.io/dbachecks-commands/

#Install-Module dbachecks
#install-module pester -SkipPublisherCheck -Force #Potential solution to issue with existing 3.4 module that ships with windows
                #more info: https://github.com/pester/Pester/wiki/Installation-and-Update#installing-from-psgallery-windows-10-or-windows-server-2016
#update-Module dbachecks
#update-module pester 

#Create a list of instances/computers to check, more: https://github.com/sqlcollaborative/dbachecks

# Set the servers you'll be working with
Set-DbcConfig -Name app.sqlinstance -Value sql2016, sql2017, sql2008, sql2008\express
Set-DbcConfig -Name app.computername -Value sql2016, sql2017, sql2008

# Look at the current configs
Get-DbcConfig

# Invoke a few tests
Invoke-DbcCheck -Checks SuspectPage, LastBackup

