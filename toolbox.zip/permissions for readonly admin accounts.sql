use master
--create login [Sparkhound\DB Administrators-Readonly] FROM WINDOWS
go
GRANT VIEW SERVER STATE TO [Sparkhound\DB Administrators-Readonly]
GRANT CONNECT ANY DATABASE TO [Sparkhound\DB Administrators-Readonly]
GRANT ALTER TRACE TO [Sparkhound\DB Administrators-Readonly]
GRANT ALTER ANY EVENT SESSION TO [Sparkhound\DB Administrators-Readonly]
GRANT VIEW ANY DEFINITION TO [Sparkhound\DB Administrators-Readonly]
GRANT SHOWPLAN TO [Sparkhound\DB Administrators-Readonly]

--One of the next two scripts will work, but only the first allows SQL Error Log access via the UI.
--However, securityadmin is virtually the same as sysadmin, since you can make yourself a sysadmin.
--There is no permission short of securityadmin/sysadmin that allows SSMS to view logs. 
ALTER SERVER ROLE [securityadmin] ADD MEMBER [Sparkhound\DB Administrators-Readonly]
--https://social.msdn.microsoft.com/Forums/en-US/11efe32b-1af5-44da-bbf7-e183e5341f2c/grant-access-to-view-sql-server-logs-from-sql-server-management-studio?forum=sqlsecurity'
--With the below permission, must use toolbox/error log.sql instead of the SSMS UI to view logs.
GRANT  EXECUTE ON xp_readerrorlog TO [Sparkhound\DB Administrators-Readonly];
GO
exec sp_msforeachdb 'use [?]; GRANT VIEW DATABASE STATE TO [Sparkhound\DB Administrators-Readonly]'

go
use msdb
go
--For SQL Agent jobs 
CREATE USER [Sparkhound\DB Administrators-Readonly] FOR LOGIN [Sparkhound\DB Administrators-Readonly]
ALTER ROLE [SQLAgentReaderRole] ADD MEMBER [Sparkhound\DB Administrators-Readonly]
ALTER ROLE [SQLAgentOperatorRole] ADD MEMBER [Sparkhound\DB Administrators-Readonly]
GRANT SELECT TO [Sparkhound\DB Administrators-Readonly]
